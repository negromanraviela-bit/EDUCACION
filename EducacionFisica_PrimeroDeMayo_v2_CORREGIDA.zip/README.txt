EDUCACIÓN FÍSICA "PRIMERO DE MAYO" - Proyecto Android corregido

Esta versión conserva el proyecto v2 y reduce dependencias AndroidX para evitar conflictos de clases y disminuir el consumo de memoria durante la compilación en FydeOS.

Cambios técnicos:
- Eliminado AppCompat.
- Biometría usa la API nativa de Android 9+.
- Se conserva OCR de Google ML Kit.
- Gradle sin daemon, sin compilación paralela y con 1 GB de heap para equipos con recursos limitados.
- No actualizar el Android Gradle Plugin durante esta compilación.

Para generar APK: Build > Generate App Bundles or APKs > Generate APKs.
