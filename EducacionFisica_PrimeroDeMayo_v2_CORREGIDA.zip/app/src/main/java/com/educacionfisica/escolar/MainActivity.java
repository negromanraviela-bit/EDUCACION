package com.educacionfisica.escolar;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.database.Cursor;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import java.util.concurrent.Executor;

public class MainActivity extends android.app.Activity {
    WebView web;
    android.content.SharedPreferences prefs;
    static final String PREFS="ef_secure";
    static final String KEY="account_blob";

    @Override protected void onCreate(Bundle b){ super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        web=findViewByIdSafe();
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(),"Android");
        web.loadUrl("file:///android_asset/index.html");
    }
    WebView findViewByIdSafe(){ setContentView(R.layout.activity_main); return findViewById(R.id.webview); }

    public class Bridge {
        @JavascriptInterface public boolean hasAccount(){ return prefs.contains(KEY); }
        @JavascriptInterface public void createAccount(String user,String pass){
            try { String blob=encrypt(user+"\n"+sha(pass)); prefs.edit().putString(KEY,blob).apply();
                web.post(()->web.evaluateJavascript("window.accountCreated && window.accountCreated()",null));
            } catch(Exception e){ web.post(()->Toast.makeText(MainActivity.this,"No se pudo guardar la cuenta",Toast.LENGTH_SHORT).show()); }
        }
        @JavascriptInterface public boolean verifyAccount(String user,String pass){
            try { String raw=decrypt(prefs.getString(KEY,"")); String[] p=raw.split("\\n",2); return p.length==2 && p[0].equals(user) && p[1].equals(sha(pass)); }
            catch(Exception e){ return false; }
        }
        @JavascriptInterface public String getUsername(){ try{String[] p=decrypt(prefs.getString(KEY,"")).split("\\n",2);return p[0];}catch(Exception e){return "";} }
        @JavascriptInterface public void biometricLogin(){
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                Toast.makeText(MainActivity.this, "La huella requiere Android 9 o posterior.", Toast.LENGTH_LONG).show();
                return;
            }
            android.hardware.biometrics.BiometricManager bm =
                    (android.hardware.biometrics.BiometricManager)getSystemService(BIOMETRIC_SERVICE);
            if (bm == null || bm.canAuthenticate() != android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS) {
                Toast.makeText(MainActivity.this, "La huella/biometría no está disponible en este dispositivo.", Toast.LENGTH_LONG).show();
                return;
            }
            android.os.CancellationSignal signal = new android.os.CancellationSignal();
            android.hardware.biometrics.BiometricPrompt prompt =
                    new android.hardware.biometrics.BiometricPrompt.Builder(MainActivity.this)
                    .setTitle("Educación Física \"Primero de Mayo\"")
                    .setSubtitle("Confirma tu identidad para entrar")
                    .setNegativeButton("Cancelar", getMainExecutor(), (dialog, which) -> {})
                    .build();
            prompt.authenticate(signal, getMainExecutor(), new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r){
                    web.post(() -> web.evaluateJavascript("window.biometricOk && window.biometricOk()", null));
                }
            });
        }
        @JavascriptInterface public void shareText(String title,String text){
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); i.putExtra(Intent.EXTRA_TITLE,title); startActivity(Intent.createChooser(i,"Compartir"));
        }
        @JavascriptInterface public void printHtml(String html,String jobName){
            WebView pv=new WebView(MainActivity.this); pv.getSettings().setJavaScriptEnabled(false); pv.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
            PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
            pm.print(jobName,pv.createPrintDocumentAdapter(jobName),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
        }
        @JavascriptInterface public void pickRosterPhoto(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,9001);
        }
        @JavascriptInterface public void ocrImage(String dataUrl){
            try {
                String b64=dataUrl.substring(dataUrl.indexOf(",")+1); byte[] bytes=Base64.decode(b64,Base64.DEFAULT);
                Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length); InputImage image=InputImage.fromBitmap(bmp,0);
                TextRecognizer r=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                r.process(image).addOnSuccessListener(t->{ String txt=t.getText().replace("\\","\\\\").replace("`","\\`").replace("${","\\${"); web.post(()->web.evaluateJavascript("window.ocrResult && window.ocrResult(`"+txt+"`)",null)); }).addOnFailureListener(e->web.post(()->Toast.makeText(MainActivity.this,"No se pudo leer la fotografía.",Toast.LENGTH_LONG).show()));
            } catch(Exception e){ Toast.makeText(MainActivity.this,"Imagen no válida.",Toast.LENGTH_SHORT).show(); }
        }
        @JavascriptInterface public void toast(String s){ Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show(); }
    }
    static String sha(String s)throws Exception{ MessageDigest md=MessageDigest.getInstance("SHA-256"); return Base64.encodeToString(md.digest(s.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP); }
    SecretKey getKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(!ks.containsAlias("EF_KEY")){ KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore"); kg.init(new android.security.keystore.KeyGenParameterSpec.Builder("EF_KEY",android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).build()); kg.generateKey(); }
        return ((KeyStore.SecretKeyEntry)ks.getEntry("EF_KEY",null)).getSecretKey();
    }
    String encrypt(String s)throws Exception{ Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,getKey()); byte[] iv=c.getIV(), enc=c.doFinal(s.getBytes(StandardCharsets.UTF_8)); return Base64.encodeToString(iv,Base64.NO_WRAP)+":"+Base64.encodeToString(enc,Base64.NO_WRAP); }
    String decrypt(String x)throws Exception{ String[] a=x.split(":",2); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,getKey(),new GCMParameterSpec(128,Base64.decode(a[0],Base64.NO_WRAP))); return new String(c.doFinal(Base64.decode(a[1],Base64.NO_WRAP)),StandardCharsets.UTF_8); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent intent){
        super.onActivityResult(requestCode,resultCode,intent);
        if(requestCode==9001 && resultCode==RESULT_OK && intent!=null && intent.getData()!=null){
            try{ Uri u=intent.getData(); InputStream in=getContentResolver().openInputStream(u); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); in.close(); String data="data:image/*;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP); web.post(()->web.evaluateJavascript("window.rosterPhotoReady && window.rosterPhotoReady('"+data+"')",null)); }catch(Exception e){Toast.makeText(this,"No se pudo abrir la fotografía.",Toast.LENGTH_SHORT).show();}
        }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
